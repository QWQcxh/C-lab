#include <stdio.h>
#include <stdlib.h>
#include <string.h>

typedef struct STACK{
    int  *elems;	//申请内存用于存放栈的元素
    int   max;	//栈能存放的最大元素个数
    int   pos;	//栈实际已有元素个数，栈空时pos=0;
}STACK;
void initSTACK(STACK *const p, int m);	//初始化p指向的栈：最多m个元素
void initSTACK(STACK *const p, const STACK&s); //用栈s初始化p指向的栈
int  size (const STACK *const p);		//返回p指向的栈的最大元素个数max
int  howMany (const STACK *const p);	//返回p指向的栈的实际元素个数pos
int  getelem (const STACK *const p, int x);	//取下标x处的栈元素
STACK *const push(STACK *const p, int e); 	//将e入栈，并返回p
STACK *const pop(STACK *const p, int &e); 	//出栈到e，并返回p
STACK *const assign(STACK*const p, const STACK&s); //赋s给p指的栈,并返回p
void print(const STACK*const p);			//打印p指向的栈
void destroySTACK(STACK*const p);		//销毁p指向的栈
bool isempty(STACK*const p);
bool isfull(STACK*const p);

void initSTACK(STACK *const p,int m){
    p->max=m;
    p->elems=(int *)malloc(sizeof(int)*p->max);
    p->pos=0;
}//初始化
void initSTACK(STACK *const p, const STACK&s){
    p->max=s.max;
    p->pos=s.pos;
    p->elems=(int*)malloc(sizeof(int)*p->max);
    int i;
    for (i=0;i<p->pos;i++){
        p->elems[i]=s.elems[i];
    }
}//复制初始
int  size (const STACK *const p){
    return p->max;
}
int  howMany (const STACK *const p){
    return p->pos;
}
int  getelem (const STACK *const p, int x){
    return p->elems[x];
}

STACK *const push(STACK *const p, int e){
    p->elems[p->pos++]=e;
    return p;
}

STACK *const pop(STACK *const p, int &e){
    e=p->elems[--p->pos];
    return p;
}
bool isempty(STACK*const p){
    return p->pos==0;
}
bool isfull(STACK*const p){
    return p->pos==p->max;
}
STACK *const assign(STACK*const p, const STACK&s)
{
    if(p->max<s.max){
        free(p->elems);
        p->elems=(int*)malloc(sizeof(int)*p->max);
    }
    p->max=s.max;
    p->pos=s.pos;
    for(int i=0;i<p->pos;i++){
        p->elems[i]=s.elems[i];
    }
    return p;
}

void print(const STACK*const p){
    int i;
    for(i=0;i<p->pos;i++)
        printf("%d  ",p->elems[i]);
}

void destroySTACK(STACK*const p){
    free(p->elems);
    free(p);
}

int main(int argc,char *argv[])
{
    // int argc=9;
    // char argv[20][20]={"U201614789","-S","10","-I","1","2","3","4","5"};
    STACK *p=(STACK*)malloc(sizeof(STACK));
    STACK *passign;
    int data,e;//
    for (int i=1;i<argc;i++){
        if(strcmp(argv[i],"-S")==0){
            data=atoi(argv[i+1]);
            if(data<=0) {
                printf("S  E  ");
                break;
            }
            initSTACK(p,data);
            printf("S  %d  ",data);
            ++i;
        }
        else if(strcmp(argv[i],"-I")==0){
            while(i+1<argc && argv[i+1][0]!='-'){
                if(!isfull(p))
                    push(p,atoi(argv[i+1]));
                else {
                    printf("I  E  ");
                    return 0;
                }
                i++;
            }
            printf("I  ");
            print(p);
        }
        else if(strcmp(argv[i],"-O")==0){
            data=atoi(argv[i+1]);
            while(data--){
                if(isempty(p)){
                    printf("O  E  ");
                    return 0;
                }
                else pop(p,e);
            }
            printf("O  ");
            print(p);
            i++;
        }
        else if(strcmp(argv[i],"-A")==0){
            ++i;
            data=atoi(argv[i]);
            passign=(STACK*)malloc(sizeof(STACK));
            initSTACK(passign,data);
            assign(passign,*p);
            destroySTACK(p);
            p=passign;
            printf("A  ");
            print(p);
        }
        else if (strcmp(argv[i],"-C")==0){
            passign=(STACK*)malloc(sizeof(STACK));
            initSTACK(passign,*p);
            destroySTACK(p);
            p=passign;
            printf("C  ");
            print(p);
        }
        else if(strcmp(argv[i],"-N")==0){
            printf("N  %d  ",p->pos);
        }
        else if(strcmp(argv[i],"-G")==0){
            ++i;
            data=atoi(argv[i]);
            if(data<0||data>p->pos-1){
                printf("G  E  ");
                return 0;
            }
            else 
                printf("G  %d  ",p->elems[data]);
        }
    }
    return 0;
}
