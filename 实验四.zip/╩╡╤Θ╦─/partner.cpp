#include <iostream>
#include <string>
#include "queue.h"
using namespace std;
void partner() {
	int M, F, m, f;
	cout << "������������������Ů��������ƥ���������Ů�˵�λ�ã���1��ʼ������" << endl;
	cin >> M >> F >> m >> f;
	QUEUE male(M); //��ʼ����
	QUEUE female(F); //��ʼŮ��
	for (int i = 1; i <= M; i++)
		male << i;
	for (int j = 1; j <= F; j++)
		female << j;
	int res;
	for (res = 1;; res++) {
		int mn, fn;
		male >> mn;
		female >> fn;
		if (mn == m && fn == f) break;
		male << mn;
		female << fn;
	}
	cout << "������Ҫ�ȴ�" << res << "�ֲ��ܺ͸�Ů������\n";
}
int main(int argc, char *argv[]) {
	if (argc == 1) { //���������
		partner();
		system("pause");
		return 0;
	}
	int i = 1; QUEUE* ps = nullptr;
		for (i = 1; i < argc; ++i)
		{
			string s = argv[i];
			if (s == "-S") {
				int num = stoi(argv[i + 1]);
				if (num <= 0) {
					cout << "S  E  "; break;
				}
				else {
					ps = new QUEUE(num);
				}
				cout << "S  " << ps->size() << "  ";
				i++;
			}
			else if (s == "-I") {
				while (i + 1 < argc && argv[i + 1][0] != '-') {
					if (ps->full()) {
						cout << "I  E  "; return 0;
					}
					else (*ps)<<(stoi(argv[i + 1]));
					i++;
				}
				cout << "I  "; ps->print();
			}
			else if (s == "-O") {
				int num, t = stoi(argv[i + 1]);
				while (t--) {
					if (int(*ps)==0) {
						cout << "O  E  "; return 0;
					}
					else {
						(*ps)>>(num);
					}
				}
				i++;
				cout << "O  "; ps->print();
			}
			else if (s == "-C") {
				QUEUE *pps;
				pps = new QUEUE(*ps);
				delete ps;
				ps = pps;
				cout << "C  ";
				ps->print();
			}
			else if (s == "-G") {
				int num = stoi(argv[i + 1]);
				if (num + 1 > int(*ps))
				{
					cout << "G  E  ";
					return 0;
				}
				cout << "G  " << (*ps)[num] << "  ";
				i++;
			}
			else if (s == "-A") {
				int num = stoi(argv[i + 1]);
				QUEUE *ptemp = new QUEUE(num);
				(*ptemp)=(*ps);
				delete ps;
				ps = ptemp;
				cout << "A  "; ps->print();
				i++;
			}
			else { //-N
				cout << "N  " << (int)(*ps);
			}
		}
}